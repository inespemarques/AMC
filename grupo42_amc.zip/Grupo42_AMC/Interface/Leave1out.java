package Interface;

import java.util.Arrays;

import dados.Amostra;
import dados.BN;
import dados.Floresta;
import dados.grafoo;

public class leave1outv1 {
	BN A;
	Amostra B=new Amostra();
	public BN aprende(Amostra w) throws Exception {
		grafoo r= new grafoo(w.list.get(0).length);
		r.amostrado(w);
		Floresta t= r.maximumSpanningTree();
		double S = 0.5;
		BN q = new BN(t,w,S);
		return q;
	}
	public boolean classificador(int[] v,int t) {
		int r=0;
		double best=0;
		int[]vv=new int[A.vectorSize];
		Arrays.fill(vv, 0);
		for (int j = 0; j < v.length; j++) {
			vv[j] = v[j];
		}
		for(int i = 0;i<A.classSize;i++) {
			vv[vv.length-1]=i;
			if(A.prob(vv)>best) {
				best=A.prob(vv);
				r=i;
			}

		}
		return(r==t);

	}

	public double leave1out(Amostra amostra, int incr) throws Exception {
		double count=0;
		int loops=0;
		for(int i =0;i<amostra.list.size();i=i+incr) {
			int v[]=amostra.list.get(0);
			amostra.remove(0);
			A=aprende(amostra);


			int res=v[v.length-1];

			if(classificador(v,res)) {
				count++;
			}

			loops++;
			amostra.list.add(v);
			System.out.println("itera��o "+ loops+" :" +(count/loops)+"      "+count+"        "+amostra.list.size());
		}
		double result=(count/loops);

		return result;
	}

	public static void main(String[] args) throws Exception {
		//		Amostra q = new Amostra("C:\\Users\\tiago\\Downloads\\amostra\\amostra\\bcancer.csv");
		//		Amostra iris = new Amostra("C:\\Users\\tiago\\Downloads\\iris.csv");
		//		Amostra letter = new Amostra("C:\\Users\\tiago\\Downloads\\letter.csv");
		//		Amostra soybean = new Amostra("C:\\Users\\tiago\\Downloads\\soybean-large.csv");
		//		Amostra satimage = new Amostra("C:\\Users\\tiago\\Downloads\\satimage.csv");
		//		Amostra diabetes = new Amostra("C:\\Users\\tiago\\Downloads\\diabetes.csv");
		Amostra q = new Amostra(("C:\\Users\\tiago\\Downloads\\amostra\\amostra\\bcancer.csv"));
		//		Amostra hepatitis = new Amostra("C:\\Users\\tiago\\Downloads\\hepatitis.csv");
		//		Amostra thyroid = new Amostra("C:\\Users\\tiago\\Downloads\\thyroid.csv");
		leave1outv1 b=new leave1outv1();
		q=q.clean(q);
		System.out.println(b.leave1out(q,1));
	}

}