package Interface;

import java.awt.Component;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Arrays;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import dados.BN;

public class Classificador extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	BN A;
	int vsize=0;
	public int Classifica(int[] v) {
		int r=0;
		double best=0;
		for(int i = 0;i<A.classSize;i++) {
			v[v.length-1]=i;
			if(A.prob(v)>best) {
				best=A.prob(v);
				r=i;
			}
		}

		return r;
	}
	public int[] stringToVector(String str) {
		// calling replaceAll() method and split() method on
		// string
		String[] string = str.replaceAll("\\[", "")
				.replaceAll("]", "")
				.split(",");

		// declaring an array with the size of string
		int[] arr = new int[vsize];
		Arrays.fill(arr, 0);

		// parsing the String argument as a signed decimal
		// integer object and storing that integer into the
		// array
		for (int i = 0; i < string.length; i++) {
			arr[i] = Integer.valueOf(string[i]);
		}
		System.out.println(Arrays.toString(arr));
		return arr;
	}
	private JPanel contentPane;
	private JTextField input;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Classificador frame = new Classificador();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Classificador() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		input = new JTextField();
		input.setText("1,0,1,1,0,1,1,1,1,1");
		input.setBounds(45, 50, 229, 19);
		contentPane.add(input);
		input.setColumns(10);
		JLabel Output = new JLabel("Resultado:");
		Output.setBounds(45, 151, 174, 41);
		contentPane.add(Output);


		JFileChooser filechooser = new JFileChooser();
		JButton chooseBN = new JButton("Choose BN");
		chooseBN.setBounds(45, 10, 140, 21);
		chooseBN.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int r = filechooser.showOpenDialog((Component)e.getSource());
				if(r== JFileChooser.APPROVE_OPTION) {
					System.out.println(filechooser.getSelectedFile());
					FileInputStream fileInput = null;
					try {
						fileInput = new FileInputStream(filechooser.getSelectedFile().getAbsolutePath());
					} catch (FileNotFoundException e1) {
						
						e1.printStackTrace();
					}
					ObjectInputStream oi = null;
					try {
						oi = new ObjectInputStream(fileInput);
					} catch (IOException e1) {
					
						e1.printStackTrace();
					}
					try {
						A = (BN) oi.readObject();
					} catch (ClassNotFoundException | IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					System.out.println(A);
					Output.setText(A.toString());
					vsize=A.vectorSize;
					System.out.println(vsize);


				}
			}
		});

		contentPane.add(chooseBN);
		JButton Classify = new JButton("Classify");
		Classify.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {



				try {
					String s = input.getText();
					System.out.println(input.getText().getClass());
					System.out.println(Arrays.toString(stringToVector(s)));
					System.out.println(Classifica(stringToVector(input.getText())));
					Output.setText("classe = "+Classifica(stringToVector(input.getText())));
				}catch(Exception ee) {
					Output.setText("valor invalido");
				}



			}
		});
		Classify.setBounds(45, 90, 156, 21);
		contentPane.add(Classify);












	}
}
