package Interface;

import java.awt.Component;
import java.awt.EventQueue;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;

import dados.Amostra;
import dados.BN;
import dados.Floresta;
import dados.grafoo;
public class Aprende extends JFrame {
	private static final long serialVersionUID = 1L;
	Amostra A;
	BN B;
	File fileToSave = null;
	FileInputStream fileInput2;
	public BN aprende(Amostra w) throws Exception {
		grafoo r= new grafoo(w.list.get(0).length);
		r.amostrado(w);
		Floresta t= r.maximumSpanningTree();
		double S = 0.5;
		BN q = new BN(t,w,S);
		return q;
	}
	
	
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Aprende frame = new Aprende();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Aprende() {
		setTitle("Learn BN");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);contentPane.setLayout(null);
		contentPane.setLayout(null);

		JTextArea textArea = new JTextArea();
		textArea.setLineWrap(true);
		textArea.setBounds(93, 75, 228, 96);
		//		contentPane.add(textArea);
		JScrollPane scroll = new JScrollPane(textArea,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		scroll.setBounds(new Rectangle(93, 75, 228, 96));

		contentPane.add(scroll);


		JFileChooser filechooser = new JFileChooser();
//		JFileChooser filechooser2 = new JFileChooser();
		JButton ReadCSV = new JButton("Read CSV File");
		ReadCSV.setBounds(93, 43, 190, 21);
		ReadCSV.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int r = filechooser.showOpenDialog((Component)e.getSource());
				if(r== JFileChooser.APPROVE_OPTION) {
					System.out.println(filechooser.getSelectedFile());
					try {
						A = new Amostra(filechooser.getSelectedFile().getAbsolutePath());
					} catch (Exception e1) {

						e1.printStackTrace();
					}
					System.out.println(A);
					textArea.setText(A.toString());

				}



			}
		});
		ReadCSV.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
		contentPane.add(ReadCSV);




		JButton Read = new JButton("Read BN");
		Read.setBounds(243, 191, 143, 21);
		Read.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				try {

					
					ObjectInputStream oi = new ObjectInputStream(fileInput2);

					B = (BN) oi.readObject();
					ArrayList<String> nova = new ArrayList<String>();
					for(int i = 0;i<B.theta.size();i++) {
						nova.add(Arrays.deepToString(B.theta.get(i)));
						nova.add("\n");
					}
					textArea.setText("eficacia= "+sucesso());
					oi.close();
					fileInput2.close();

				}catch(Exception ee) {
					ee.printStackTrace();						
				}
			}
		}
				);
		contentPane.add(Read);
		JButton Save = new JButton("Learn and Save BN");
		Save.setBounds(50, 191, 150, 21);
		Save.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				FileOutputStream fileOut;
				try {
					JFrame parentFrame = new JFrame();

					JFileChooser fileChooser = new JFileChooser();
					fileChooser.setDialogTitle("Specify a file to save");   

					int userSelection = fileChooser.showSaveDialog(parentFrame);

					if (userSelection == JFileChooser.APPROVE_OPTION) {
						fileToSave = (fileChooser.getSelectedFile());
						fileInput2 = new FileInputStream(fileChooser.getSelectedFile().getAbsolutePath());
						System.out.println("Save as file: " + fileToSave.getAbsolutePath());
					}
					fileOut = new FileOutputStream(fileToSave.getAbsolutePath());
					ObjectOutputStream objectOut = new ObjectOutputStream(fileOut);
					System.out.println(filechooser.getSelectedFile().getAbsolutePath());
					objectOut.writeObject(aprende(A));
					objectOut.close();
					fileOut.close();
					textArea.setText("Saved Successfully.");
				}catch(Exception ee) {
					ee.printStackTrace();
				}




			}
		});
		contentPane.add(Save);




	}
	public int Classifica(int[] v) {
		int r=0;
		double best=0;
		for(int i = 0;i<B.classSize;i++) {
			v[v.length-1]=i;
			if(B.prob(v)>best) {
				best=B.prob(v);
				r=i;
			}
		}
		return r;
	}
	public double sucesso() {
		int certo=0;
		int[]v= new int[B.vectorSize];
		Arrays.fill(v, 0);
		int estimado=0;
		double sucessos=0;
		for (int i=0;i<A.list.size();i++) {
			certo=A.list.get(i)[v.length-1];
			for(int j=0;j!=v.length-1;j++)
				v[j]=A.list.get(i)[j];
			estimado=Classifica(v);
			if(certo==estimado) {
				sucessos=sucessos+1;
				System.out.println(sucessos);
			}
			
		}
		
		double r = sucessos/A.list.size();
 		
		return r;
	}
}
