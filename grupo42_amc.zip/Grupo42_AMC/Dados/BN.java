package dados;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
public class BN implements Serializable{
	private static final long serialVersionUID = 1L;
	Floresta G;
	//primeiro bloco percorre todos os nos com exce��o da classe e faz os tetas
	public ArrayList<double[][]> theta;
	public int vectorSize;
	public int classSize;
	public BN(Floresta tree, Amostra amostra,double S) throws Exception {
		vectorSize=amostra.list.get(0).length;
		classSize=amostra.domain(amostra.element(0).length-1);
		ArrayList<double[][]> r = new ArrayList<double[][]>();   // a arrayList � a lista com a matriz la dentro em que a posi�ao no arraylist � o n� (filho)
		for(int i =0; i < tree.nodes-1; i++) {                   // percorre as posicoes na arraylist ou seja os nos da arvore
			// n� filho = i
			ArrayList<Integer> parent= new ArrayList<Integer>();
			parent.add(tree.parent(i));                           // lista so com o pai de i, para depois usar no count
			ArrayList<Integer> sp = new ArrayList<Integer>();
			Collections.addAll(sp,i,tree.parent(i));               // lista com o pai e o filho
			int sonDomain = amostra.domain(i);                   // dominio do filho
			int parentDomain=amostra.domain(parent.get(0));
			double[][] m = new double [sonDomain][parentDomain];
			for(int j = 0;j<sonDomain;j++) {			// percorre os valores possiveis dos filhos
				for(int k=0;k<parentDomain;k++) {		// percorre os valores possiveis do pai
					ArrayList<Integer> s_p_val = new ArrayList<Integer>();
					Collections.addAll(s_p_val,j,k);
					ArrayList<Integer> p_val = new ArrayList<Integer>();
					p_val.add(k);
					m[j][k]=(amostra.count(sp, s_p_val)+S)/(amostra.count(parent, p_val)+S*sonDomain);	//faz a conta do teta para cada valor de pai e de filho

				}
				r.add(i,m);
			}
		}
		//segundo bloco faz os tetas para classe e adiciona a arraylist
		ArrayList<Integer> temp_tree= new ArrayList<Integer>();
		temp_tree.add(tree.nodes-1);
		int class_domain = amostra.domain(tree.nodes-1);
		double[][] Class = new double[class_domain][1];
		for( int i=0;i<class_domain;i++) {       // o ciclo percorre o valores possiveis (l) da classe
			ArrayList<Integer> class_index = new ArrayList<Integer>();
			class_index.add(tree.nodes-1);			//adiciona a arraylist mais uma matriz com o teta para a class
			ArrayList<Integer> class_values =new ArrayList<Integer>();
			class_values.add(i);					// cria uma array list so com o valor possivel do n� para poder fazer a contagem
			Class[i][0] = (double)(amostra.count(class_index,class_values))/(amostra.length());		// o numero de vezes que se observa l na classe a dividir pelo tamanho da amostra
		}
		r.add(tree.nodes-1,Class);		// adiciona ao arrayList de matrizes dos tetas
		theta = r;// metodo construtor
		G =tree;// metodo construtor


	}

	public double prob(int v[]) {  //Devolve a prob de um vetor com base na rede de Bayes
		double r = 1;
		for(int i = 0; i<G.nodes-1;i++) {     // i = Xi
			int i_parent= G.parent(i);        // pai de i
			double p;
			if (!G.parentQ(i)) { // calculo da prob no caso da raiz
				p= theta.get(i)[v[i]][0];
			}else {              // calculo da prob no resto dos nós
				p = theta.get(i)[v[i]][v[i_parent]];
			}
			r*=p;
		}
		return r;
	}


}


