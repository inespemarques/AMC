package amc_project;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;

public class grafoo implements Serializable{
	
	private static final long serialVersionUID = 1L;
	int dim;
	double[][] ma;
	
	public grafoo(int n) { //recebe um natural n e retorna um grafo com n n�s e sem arestas
		this.dim=n;
		this.ma=new double[dim][dim];
	}
	
	public void add_edge(int m, int n, double p) { //recebe 2 n�s e um peso. adiciona uma aresta entre estes 2 n�s com esse peso
		if (0<=m && m < dim && 0<=n && n < dim) {
			ma[m][n]=p; //na matriz, adiciona de n para m e de m para n porque � n�o direcionado
			ma[n][m]=p;
		}
		else {
			throw new RuntimeException("vertice n�o existe");
		}
	}
	
	public int findMaxVertex(boolean visited[],double weights[]){ //fun��o para encontrar o v�rtice cuja aresta tem peso m�ximo

		int index = -1; //guarda o �ndice do v�rtice de maior peso que ainda n�o foi visitado

		double maxW = Double.MIN_VALUE; //guarda o peso m�ximo dos vertices n�o-visitados

		for (int i = 0; i < dim; i++) //percorre todos os n�s do grafo
		{
			if (visited[i] == false && weights[i] > maxW) //se ainda n�o visit�mos este n� e o peso dele � maior do que o guardado anteriormente
			{
				maxW = weights[i]; //mudamos o valor de maxW para o novo (update)
				index = i; //fazemos update do �ndice deste v�rtice
			}
		}
		return index;
	}

	
	public Floresta printMaximumSpanningTree(int parent[]){ //fun��o que manda para fora a MaxSpanningTree
		
		Floresta output = new Floresta(dim);
		
		for (int i = 0; i < dim-1; i++){ //d� print das arestas e respetivos pesos da MST
			
			output.set_parent(i,parent[i]);
			output.set_weigth(i, ma[i][parent[i]]);
		}
		return output;
	}

	
	public Floresta maximumSpanningTree(){ //fun��o para encontrar a MST

		boolean[] visited = new boolean[dim]; // visited[i]: verifica se o v�rtice i j� foi ou n�o visitado

		// weights[i]: Stores maximum weight of
		// graph to connect an edge with i
		double[] weights = new double[dim]; // weights[i]: guarda o peso m�ximo do grafo para conectar uma aresta com o v�rtice i.

		int[] parent = new int[dim]; // parent[i]: guarda o n� pai do v�rtice i

		for (int i = 0; i < dim; i++) { // inicia a variavel "pesos" como -INFINITO e a variavel "visitados" como falso.
			visited[i] = false;
			weights[i] = Double.MIN_VALUE;
		}

		// Include 1st vertex in
		// maximum spanning tree
		weights[dim-1] = Integer.MAX_VALUE;
		parent[dim-1] = -1;

		for (int i = 0; i < dim - 1; i++) { //vamos � procura dos restantes v�rtices

			int maxVertexIndex= findMaxVertex(visited, weights); //guarda o �ndice do v�rtice de maior peso (dentro dos v�rtices n�o-visitados)

			visited[maxVertexIndex] = true; //diz q esse v�rtice j� foi visitado

			for (int j = 0; j < dim-1; j++) { //faz update dos v�rtices adjacentes do v�rtice que est� a ser visitado

				if (ma[j][maxVertexIndex] != 0 && visited[j] == false) { //se h� uma aresta entre j e o v�rtice que est� a ser visitado, e se j est� por visitar

					// If graph[v][x] is
					// greater than weight[v]
					if (ma[j][maxVertexIndex] > weights[j]) {

						// Update weights[j]
						weights[j]= ma[j][maxVertexIndex];

						// Update parent[j]
						parent[j] = maxVertexIndex;
					}
				}
			}
		}

		// Print maximum spanning tree
		return(printMaximumSpanningTree(parent));
	}
	public double pesagem (int o, int d, Amostra amostra) throws Exception { //fun��o para 
		
		if (0<=o && o<this.dim && 0<=d && d<this.dim) {
			double r = 0;
			ArrayList<Integer> X= new ArrayList<Integer>(); /// criar vetores com as vari�vies para a fun��o count
			X.add(o);
			ArrayList<Integer> Y= new ArrayList<Integer>();
			Y.add(d);
			ArrayList<Integer> X_Y= new ArrayList<Integer>();				
			X_Y.add(o);
			X_Y.add(d);
			for(int i=0;i<(amostra.domainV()).get(o);i++) { /// somat�rio no dominio de X
				double p = 0;
				for(int j=0;j<amostra.domainV().get(d);j++) {	/// somat�rio no dominio de Y
					ArrayList<Integer> x= new ArrayList<Integer>(); /// criar vetores com as vari�vies para a fun��o count
					x.add(i);
					ArrayList<Integer> y= new ArrayList<Integer>();
					y.add(j);
					ArrayList<Integer> x_y= new ArrayList<Integer>();				
					x_y.add(i);
					x_y.add(j);
					double pxy=(double)(amostra.count(X_Y, x_y))/amostra.length();			/// probabilidade de Y tomar o valor y e X tomar o valor x nos dados
					if (pxy==0.0)
						p += 0;
					else {
						double py = (double)amostra.count(Y, y)/amostra.length();			/// probabilidade de Y tomar o valor y nos dados
						double px = (double)amostra.count(X, x)/amostra.length();			/// probabilidade de X tomar o valor x nos dados
						p += pxy*Math.log(pxy/(py*px));
					}
				}
				r += p;
			}
			return r;
		} else {
			throw new RuntimeException("Error: o and/or d not in range");
		}
	}
	public void amostrado(Amostra amostra) throws Exception { // pega na amostra e converte num grafo pesado
		for(int i = 0; i<this.dim;i++) {
			for(int j=0;j<=i;j++) {
				if(i==j) {
					this.add_edge(i, j, 0);
				}else {
					this.add_edge(i, j, pesagem(i,j,amostra));
				}
			}
		}
	}
}