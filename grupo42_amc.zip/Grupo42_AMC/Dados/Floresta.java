package dados;
import java.io.Serializable;
import java.util.Arrays;
public class Floresta implements Serializable{
	private static final long serialVersionUID = 1L;
	public int nodes;
	public int LP[];	//lista de pais
	public double LW[];	//lista de peso do do indice para o pai

	public Floresta(int n) {
		LP = new int[n];
		LW = new double[n];
		this.nodes=n;
		Arrays.fill(LP,-1);
	}
	public void set_parent(int n,int m) {
		LP[n]=m;	//m é pai de n
	}
	public void set_weigth(int n, double p) {
		LW[n]=p;	//define que  o peso do nó n para o pai é p
	}
	public double weight(int n) {
		return LW[n];
	}
	public int parent(int n) {
		return LP[n];
	}
	public boolean parentQ(int o) {
		return(parent(o)!=-1);
	}
	public boolean treeQ() {//verifica se a floresta é uma árvore
		int c=0;
		for(int i=0; i<LP.length;i++) {
			if(LP[i]==-1) {
				c++;
			}
		}
		return(c==1);
	}
}