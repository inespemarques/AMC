package dados;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;

public class Amostra implements Serializable{
	private static final long serialVersionUID = 1L;
	public ArrayList<int []> list;


	public Amostra() {
		this.list = new ArrayList<int []>();
	}

	public Amostra(String csvFile) throws Exception {
		list = new ArrayList<int []>();;

		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";

		try {br = new BufferedReader(new FileReader(csvFile));
		while ((line = br.readLine()) != null) {

			// use comma as separator
			String[] country     = line.split(cvsSplitBy);
			int[] stringToIntVec = new int[country.length];
			for (int i = 0; i < country.length; i++)
				stringToIntVec[i] = Integer.parseInt(country[i]);	
			add(stringToIntVec);
		}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public void add (int[] v){//adiciona um vetor v � amostra na ultima posicao desta
		list.add(v);
	}

	public void remove(int p) {//remove o vetor da posi��o i da amostra
		list.remove(p);
	}

	public int length() {//retorna o comprimento da amostra
		int l =list.size();
		return l;
	}

	public int[] element (int p){//retorna o elemento na posi��o p da amostra
		int[] output=list.get(p);
		return output;
	}

	public int domain(int pos) {//recebe um vetor de posicoes e devolve o produto dos dominios correspondentes
		if (0>pos || pos <list.size()) {
			ArrayList<Integer> pv=new ArrayList<Integer>();
			for(int i=0;i<length();i++) {//percorrer toda a amostra
				if(!pv.contains(list.get(i)[pos])) {
					pv.add(list.get(i)[pos]);//vai armazenando no vetor pv todas os elementos da amostra que a variavel pos � capaz de tomar
				}
			}
			return pv.size();//retorna o comprimento da pv
		}else {
			throw new RuntimeException("posi��o n�o existe");
		}
	}

	public ArrayList<Integer> domainV() throws Exception{//retorna um vetor com os dom�nios de cada vari�vel dos elementos da amostra
		ArrayList<Integer> r=new ArrayList<Integer>();
		for(int i = 0;i<list.get(1).length;i++) {//faz o domain para todas as variaveis e adiciona � arraylist r
			r.add(this.domain(i));
		}
		return r;
	}

	public int count(ArrayList<Integer> var, ArrayList<Integer> val) {
		//recebe um vetor de posicoes e um vetor de valores  
		//devolve o numero de vezes que ocorrem simultaneamente os valores nas posicoes correpondentes
		int c = 0;
		for (int i = 0; i < list.size(); i++) {//percorre a amostra
			boolean found = true;
			for (int j = 0; j < var.size(); j++) {//percorre var
				if (list.get(i)[var.get(j)]!=val.get(j)) {//se o vetor i da amostra tiver na posicao var[j] o valor de val[j] acrescenta 1 a c
					found=false;
				}
			}
			if (found) {
				c=c+1;
			}
		}
		return c;
	}

	@Override
	public String toString() {
		String s="[";
		if (list.size()>0) s+=Arrays.toString(list.get(0));
		for (int i=1; i<list.size();i++)
			s+=","+Arrays.toString(list.get(i));
		s+="]";

		//		return " Amostra = " + s;              // teste sem "AMOSTRA"
		return s;
	}

	public ArrayList<Integer> lixo(Amostra a) throws Exception{
		//cria uma arraylist com as variaveis que t�m dominio 1
		ArrayList<Integer> l=new ArrayList<Integer>();
		ArrayList<Integer>v=a.domainV();
		for(int i=0;i<v.size();i++) {
			if(v.get(i)==1) {// se dominio for igual a um, acrescenta a variavel a arraylist l
				l.add(i);
			}
		}
		return l;
	}

	public Amostra clean(Amostra a) throws Exception {
		//retira da amostra todos os elementos que t�m dominio 1
		ArrayList<Integer> l=a.lixo(a);
		Amostra b=new Amostra();
		if(!l.isEmpty()) {
			for(int i=0;i<a.list.size();i++) {//percorre a amostra
				int[]n=new int[a.list.get(0).length-l.size()];//novo vetor com tamanho original menos o num de variaveis de lixo
				int c=0;
				for(int j=0;j<a.list.get(0).length;j++) {//vai percorrer todas as posicoes de cada vetor

					if(!l.contains(j)) {//se a variavel j n�o estiver em lixo
						n[c]=a.list.get(i)[j];//vai acrescentando ao vetor n os elementos das variaveis que n�o t�m dominio 1
						c++;
					}
				}
				b.add(n);
			}
		}else {
			return a;
		}
		return b;
	}


}